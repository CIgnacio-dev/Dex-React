import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import PokemonDetail from './pages/PokemonDetaill'
import Favorites from './pages/Favorites'


function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/pokemon/:name" element={<PokemonDetail />} />
      <Route path="/favoritos" element={<Favorites />} />
    </Routes>
  )
}
export default App