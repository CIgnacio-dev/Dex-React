import { useEffect, useState } from 'react'
import {
  Box,
  Button
} from '@chakra-ui/react'
import { useSearchParams } from 'react-router-dom'
import { Link } from 'react-router-dom'

import { getPokemons, getAllPokemons } from '../services/api'
import SearchBar from '../components/SearchBar'
import PokemonGrid from '../components/PokemonGrid'
import Pagination from '../components/Pagination'
import LoadingSkeletons from '../components/LoadingSkeletons'

function Home() {
  const [searchParams, setSearchParams] = useSearchParams()
  const page = parseInt(searchParams.get('page')) || 1
  const limit = 20
  const total = 1010
  const totalPages = Math.ceil(total / limit)
  const offset = (page - 1) * limit

  const [pokemons, setPokemons] = useState([])
  const [allPokemons, setAllPokemons] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selectedType, setSelectedType] = useState('')

  // Cargar todos los Pokémon (para búsqueda + tipos)
  useEffect(() => {
    getAllPokemons().then(data => setAllPokemons(data))
  }, [])

  // Cargar Pokémon por página (cuando no hay búsqueda)
  useEffect(() => {
    setLoading(true)
    getPokemons(limit, offset)
      .then(data => setPokemons(data))
      .finally(() => setLoading(false))
  }, [offset])

  // Aplicar filtros (nombre + tipo)
  const filteredPokemons = (search ? allPokemons : pokemons).filter(p =>
    p.name.includes(search) &&
    (!selectedType || p.types?.includes?.(selectedType))
  )

  return (
    <Box p={6}>
        <Button as={Link} to="/favoritos" colorScheme="yellow" size="sm">
  ⭐ Ver favoritos
</Button>
      {/*  Buscador + Filtro por tipo */}
      <SearchBar
        search={search}
        onSearch={setSearch}
        selectedType={selectedType}
        onSelectType={setSelectedType}
      />

      {/* Grid de resultados */}
      <Box mt={6}>
        {loading
          ? <LoadingSkeletons count={20} />
          : <PokemonGrid
              pokemons={filteredPokemons}
              loading={false}
              selectedType={selectedType}
            />
        }
      </Box>


      
      {!search && (
        <Pagination
          page={page}
          totalPages={totalPages}
          onPageChange={(newPage) => setSearchParams({ page: newPage })}
        />
      )}
    </Box>
  )
}

export default Home
